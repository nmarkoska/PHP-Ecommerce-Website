<!DOCTYPE html>
<html lang="en">
<!-- About us page-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">About Us</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                </div>
            </div>
        </header>


   
     
            
        </div>
        </section>
        <body>
                        <p class="aboutus">Hi! Welcome to our shop. We are Ana and Neda, the founders of ANNE online makeup store. We want to present to you our view of a lady's heaven. We really hope that you will enjoy it buying as much as we enjoyed creating it. </p>
</br>
<p class= "aboutus"> “Treat your makeup like jewelry for the face. Play with colors, shapes, structure – it can transform you.” – Francois Nars" </p>
                        <style>
                            p.aboutus {
  color: #082744;
  font-size: 26px;
  font-family: monospace;
  font-style: italic;
  text-align: center;
  margin-left: 60px;
  margin-right: 60px;
  padding-top: 20px;
}
}
                            </style>
                    </body>
        </html>