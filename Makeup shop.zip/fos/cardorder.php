<?php

session_start();
   
include('admin/db_connect.php'); 

$cardnumber=$_POST["cardnumber"];
$date=$_POST["date"];
$cvv=$_POST["cvv"];

$id=$_SESSION['login_user_id'];
echo $id;
$qry="UPDATE `user_info` SET `cardnumber`='$cardnumber',`date`='$date',`cvv`='$cvv' WHERE user_id=$id";
echo $qry;
mysqli_query($conn, $qry);

header('location:index.php')

?>

   